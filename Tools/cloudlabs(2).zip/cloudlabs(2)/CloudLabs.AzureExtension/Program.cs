﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Net.Http;
using System.Globalization;
using System.Net;
using System.Threading;
using System.Runtime.InteropServices;

namespace CloudLabs.AzureExtension
{
    class Program
    {
        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        const int SW_HIDE = 0;
        const int SW_SHOW = 5;

        static string StorageAccountName = "clsupload";
        static string StorageAccountKey = "g5DCYC+Q2pQaeVxLtwphEXztiBnBODRm+C1nX0z7JzP6jOjyAggfeq3Lu9//OS0A24Yxq0EoNoekis68/dEKcA==";
        static string CurrentExePath = "";

        static void Main(string[] args)
        {
            //NOT USING THIS CODE NOW. SO COMMENTING ALL CODE.

            ////var handle = GetConsoleWindow();

            ////// Hide
            ////ShowWindow(handle, SW_HIDE);

            ////// Get this process priority to the highest
            ////// Console.WriteLine(Process.GetCurrentProcess().PriorityClass);
            ////Process.GetCurrentProcess().StartInfo.UseShellExecute = false;
            ////Process.GetCurrentProcess().PriorityClass = ProcessPriorityClass.RealTime;
            ////CurrentExePath = Process.GetCurrentProcess().MainModule.FileName;
            //////Console.WriteLine(Process.GetCurrentProcess().PriorityClass);

            ////string pubIp = "0.0.0.0";
            ////try
            ////{
            ////    pubIp = new System.Net.WebClient().DownloadString("https://api.ipify.org");
            ////}
            ////catch (Exception)
            ////{
            ////}

            ////while (true)
            ////{
            ////    Console.Write(".");
            ////    MonitorProcs(pubIp);
            ////    Thread.Sleep(5 * 60 * 1000);
            ////}

            ////Console.ReadLine();
        }

        static void MonitorProcs(string pubIp)
        { 
            int rLevel = 0;
            int pCount = 0;
            string message = "";
            var pList = Process.GetProcesses();
            Dictionary<string, int> procCount = new Dictionary<string, int>();

            foreach (var process in pList.ToList())
            {
            //Console.WriteLine(process.ProcessName);
            //Console.WriteLine(process.UserProcessorTime);
            ////if (process.PriorityClass == ProcessPriorityClass.High ||
            ////    process.PriorityClass == ProcessPriorityClass.AboveNormal ||
            ////    process.PriorityClass == ProcessPriorityClass.RealTime)
            ////{

            ////}
            ///
            

                //Console.WriteLine(process.StartInfo.UserName);

                try
                {
                    string procFileName = process.MainModule.FileName.ToLower();
                    if (procCount.Keys.Contains(procFileName))
                    {
                        procCount[procFileName] = procCount[procFileName] + 1;
                    }
                    else
                    {
                        procCount[procFileName] = 1;
                    }

                    bool shouldLog = false;
                    shouldLog = process.TotalProcessorTime > TimeSpan.FromMinutes(2) || (
                            !process.MainModule.FileName.StartsWith(@"C:\Windows\System32\", StringComparison.OrdinalIgnoreCase) &&
                            !process.MainModule.FileName.StartsWith(@"C:\Program Files (x86)\", StringComparison.OrdinalIgnoreCase) &&
                            !process.MainModule.FileName.StartsWith(@"C:\Program Files\", StringComparison.OrdinalIgnoreCase) &&
                            !process.MainModule.FileName.StartsWith(@"C:\WindowsAzure\", StringComparison.OrdinalIgnoreCase) &&
                            !process.MainModule.FileName.StartsWith(@"C:\Windows\SysWOW64\", StringComparison.OrdinalIgnoreCase) &&
                            !process.MainModule.FileName.Equals(CurrentExePath, StringComparison.OrdinalIgnoreCase)
                        );

                    if (shouldLog)
                    {
                        TimeSpan totalProcessorTime = TimeSpan.FromMinutes(0);
                        try
                        {
                            totalProcessorTime = process.TotalProcessorTime;
                        }
                        catch (Exception)
                        {
                        }

                        //Console.WriteLine(process.ProcessName + " -- " + process.MainModule.FileName + " -- " + process.TotalProcessorTime);
                        message += process.ProcessName + " -- " + process.MainModule.FileName + " -- " + totalProcessorTime + "\r\n";
                        if (rLevel == 0)
                        {
                            rLevel = 1;
                        }

                        if (process.MainModule.FileName.ToLower().Contains("mine") ||
                            procCount[procFileName] >= 3)
                        {
                            rLevel = 3;
                        }

                        if (rLevel == 1 && 
                            !process.MainModule.FileName.StartsWith(@"C:\Windows\System32\", StringComparison.OrdinalIgnoreCase) &&
                            !process.MainModule.FileName.StartsWith(@"C:\Program Files (x86)\", StringComparison.OrdinalIgnoreCase) &&
                            !process.MainModule.FileName.StartsWith(@"C:\Program Files\", StringComparison.OrdinalIgnoreCase))
                        {
                            rLevel = 2;
                        }

                        pCount++;
                    }
                }
                catch (Exception)
                {
                    //Console.WriteLine(process.ProcessName);
                }
            }

            string ts = DateTime.UtcNow.ToString("yyyy-MM-dd-HH-mm.ss");
            string name = pubIp + "_" + "r" + rLevel + "_" + ts + "_" + pCount.ToString("000") + ".txt";
            UploadContent(name, message, CancellationToken.None).GetAwaiter().GetResult();
        }

        internal static async Task UploadContent(string name, string message, CancellationToken cancellationToken)
        {
            String uri = string.Format("https://{0}.blob.core.windows.net/scn/{1}", StorageAccountName, name);

            // Set this to whatever payload you desire. Ours is null because 
            //   we're not passing anything in.
            Byte[] requestPayload = System.Text.Encoding.UTF8.GetBytes(message);

            //Instantiate the request message with a null payload.
            using (var httpRequestMessage = new HttpRequestMessage(HttpMethod.Put, uri)
            { Content = (requestPayload == null) ? null : new ByteArrayContent(requestPayload) })
            {

                // Add the request headers for x-ms-date and x-ms-version.
                DateTime now = DateTime.UtcNow;
                httpRequestMessage.Headers.Add("x-ms-date", now.ToString("R", CultureInfo.InvariantCulture));
                httpRequestMessage.Headers.Add("x-ms-version", "2017-04-17");
                httpRequestMessage.Headers.Add("x-ms-blob-type", "BlockBlob");
                httpRequestMessage.Content.Headers.ContentLength = requestPayload.LongLength;

                // Add the authorization header.
                httpRequestMessage.Headers.Authorization = AzStorageAuthHelper.GetAuthorizationHeader(
                   StorageAccountName, StorageAccountKey, now, httpRequestMessage);

                // Send the request.
                using (HttpResponseMessage httpResponseMessage = await new HttpClient().SendAsync(httpRequestMessage, cancellationToken))
                {
                    // If successful (status code = 200), 
                    if (httpResponseMessage.StatusCode == HttpStatusCode.OK)
                    {
                        //String responseStr = await httpResponseMessage.Content.ReadAsStringAsync();
                        //Console.WriteLine(responseStr);
                    }
                }
            }
        }
    }
}
