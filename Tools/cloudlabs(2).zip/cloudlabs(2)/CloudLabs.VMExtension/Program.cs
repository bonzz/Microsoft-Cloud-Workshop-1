﻿using System;
using System.Runtime.InteropServices;

namespace CloudLabs.VMExtension
{
    public static class Program
    {
        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        const int SW_HIDE = 0;
        const int SW_SHOW = 5;

        static void Main(string[] args)
        {
            if (args.Length == 6)
            {
                //Console.SetWindowSize(1, 1);
                //Console.SetWindowPosition(0, 0);
                try
                {
                    var handle = GetConsoleWindow();

                    // Hide
                    ShowWindow(handle, SW_HIDE);

                    // Show
                    //ShowWindow(handle, SW_SHOW);
                }
                catch(Exception)
                {
                }
                

                var domain = args[0];
                var subId = args[1];
                var username = args[2];
                var password = args[3];
                var rgName = args[4];
                var url = args[5];

                Console.WriteLine("Launching Azure Portal :");
                AzureLoginManager.Login(domain, subId, username, password, rgName, url);
            }

            Console.ReadLine();
        }
    }
}
