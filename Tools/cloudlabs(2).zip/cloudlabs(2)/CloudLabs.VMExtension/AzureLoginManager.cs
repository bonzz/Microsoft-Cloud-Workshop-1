﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Configuration;


namespace CloudLabs
{
    /// <summary>
    /// Handler to enable login to Azure Portal.
    /// </summary>
    public static class AzureLoginManager
    {
        public static void Login(string domain,string subscriptionId,string username,string password,string rgName,string url)
        {
            // 1. Load Chrome Browser
            IWebDriver driver = new ChromeDriver(ConfigurationManager.AppSettings["Chrome.Driver.Path"]);
            driver.Navigate().GoToUrl("https://portal.azure.com");
            Wait(driver, 10000);

            // 2. Maximize Chrome Browser
            driver.Manage().Window.Maximize();

            // 3. Type in username
            var elUsername = driver.FindElement(By.Name(ConfigurationManager.AppSettings["AzurePortal.Username.Element.Name"]));
            elUsername.SendKeys(username);
            elUsername.SendKeys(Keys.Enter);
            Wait(driver, 10000);

            // 4. Type in password
            var elPassword = driver.FindElement(By.Name(ConfigurationManager.AppSettings["AzurePortal.Password.Element.Name"]));
            elPassword.SendKeys(password);
            Wait(driver, 2000);

            // 5. Submit password
            elPassword.SendKeys(Keys.Enter);
            Wait(driver, 5000);

            // 6. Click on the prompt
            var button = driver.FindElement(By.Id(ConfigurationManager.AppSettings["AzurePortal.Submit.Element.Name"]));
            button.Click();
            Wait(driver, 5000);

            // 7. Launch the specific Resource Group if present.
            if (!string.IsNullOrEmpty(domain) &&
                !string.IsNullOrEmpty(subscriptionId) &&
                !string.IsNullOrEmpty(rgName))
            {
                driver.Navigate().GoToUrl(url);
                Wait(driver, 5000);
            }
        }

        private static void Wait(this IWebDriver driver, int miliseconds, int maxTimeOutSeconds = 60)
        {
            var wait = new WebDriverWait(driver, new TimeSpan(0, 0, 1, maxTimeOutSeconds));
            var delay = new TimeSpan(0, 0, 0, 0, miliseconds);
            var timestamp = DateTime.Now;
            wait.Until(webDriver => (DateTime.Now - timestamp) > delay);
        }
    }
}
